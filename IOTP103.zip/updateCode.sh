#!/bin/bash

scp -r Firmware/* pi@raspberrypi.local:/home/pi/Firmware